//
//  AllUserTableViewCell.swift
//  BornToughTrainer
//
//  Created by Syed ShahRukh Haider on 06/08/2018.
//  Copyright © 2018 MAQ. All rights reserved.
//

import UIKit

class AllUserTableViewCell: UITableViewCell {

    @IBOutlet weak var Name: UILabel!
    
    @IBOutlet weak var userImage: Custom_ImageView!
    
}
