//
//  pepTalkTVC.swift
//  BornToughTrainer
//
//  Created by MAQ on 7/23/18.
//  Copyright © 2018 MAQ. All rights reserved.
//

import UIKit

class pepTalkTVC: UITableViewCell {

    @IBOutlet weak var popTitle: UILabel!
    @IBOutlet weak var pepPlay: UIButton!
    @IBOutlet weak var pepDelete: UIButton!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
