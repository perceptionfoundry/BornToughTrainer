//
//  gradeListTVC.swift
//  BornToughTrainer
//
//  Created by admin on 20/07/2018.
//  Copyright © 2018 MAQ. All rights reserved.
//

import UIKit

class gradeListTVC: UITableViewCell {

    @IBOutlet weak var grade: UILabel!
    @IBOutlet weak var gradeDate: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
